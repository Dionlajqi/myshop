using System;
using System.Security.Cryptography.X509Certificates;
namespace myshop.Models
{
    public class Item
    {
        public int ItemId {get; set;}

        public string Name {get; set;} = string.Empty;

        public decimal Price {get; set;}

        public string? Description {get; set;}

        public string? ImageURL {get; set;}

    }
}